package com.champlain.oop2assignment2;

public enum Suit {
    CLUBS, DIAMONDS, SPADES, HEARTS
}
